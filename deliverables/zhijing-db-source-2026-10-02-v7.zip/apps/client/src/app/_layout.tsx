import { Stack, router, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { AppProvider, useApp } from "../state/app-context";

export default function RootLayout() {
  return <AppProvider><RootNavigator /></AppProvider>;
}

function RootNavigator() {
  const { currentUser, ready } = useApp(); const segments = useSegments();
  useEffect(() => { if (ready && !currentUser && segments[0] === "(tabs)") router.replace("/"); }, [ready, currentUser, segments]);
  return <><StatusBar style="light" /><Stack screenOptions={{ headerShown: false }} /></>;
}
