import { Annotation, END, MemorySaver, START, StateGraph, type BaseCheckpointSaver } from "@langchain/langgraph";
import { PostgresSaver } from "@langchain/langgraph-checkpoint-postgres";
import { buildMockRunEvents, generateMockResource, planLearningPath } from "@zhijing/agents";
import { getKnowledgeNode } from "@zhijing/course-data";
import type { AgentEvent, DemoUser, LearningResource } from "@zhijing/shared";
import { createModelProvider } from "./model.js";

const WorkflowState = Annotation.Root({
  runId: Annotation<string>(),
  user: Annotation<DemoUser>(),
  nodeId: Annotation<string>(),
  type: Annotation<LearningResource["type"]>(),
  resource: Annotation<LearningResource | undefined>(),
  events: Annotation<AgentEvent[]>({ reducer: (current, update) => [...current, ...update], default: () => [] }),
});

const model = createModelProvider();
const memorySaver = new MemorySaver();
let postgresSaverPromise: Promise<PostgresSaver> | undefined;

async function getCheckpointer(): Promise<BaseCheckpointSaver> {
  if (!process.env.DATABASE_URL) return memorySaver;
  postgresSaverPromise ??= (async () => {
    const saver = PostgresSaver.fromConnString(process.env.DATABASE_URL!, { schema: "langgraph" });
    await saver.setup();
    return saver;
  })();
  return postgresSaverPromise;
}

function event(runId: string, agent: AgentEvent["agent"], progress: number, summary: string): AgentEvent[] {
  return [{ runId, agent, status: "completed", progress, summary, elapsedMs: 0, timestamp: new Date().toISOString() }];
}

async function buildGraph() {
  const checkpointer = await getCheckpointer();
  return new StateGraph(WorkflowState)
    .addNode("orchestrate", (state) => ({ events: event(state.runId, "Orchestrator", 10, "已创建固定工作流并载入检查点") }))
    .addNode("profile", (state) => ({ events: event(state.runId, "ProfileAgent", 25, "已读取八维学习画像") }))
    .addNode("diagnose", (state) => ({ events: event(state.runId, "DiagnosisAgent", 40, `已定位 ${state.nodeId} 知识断点`) }))
    .addNode("path", (state) => {
      const active = planLearningPath(state.user.profile).find((step) => step.nodeId === state.nodeId);
      return { events: event(state.runId, "PathAgent", 55, active?.reason ?? "已校验知识依赖与资源策略") };
    })
    .addNode("generate", async (state) => {
      const fallback = generateMockResource({ user: state.user, nodeId: state.nodeId, type: state.type });
      const node = getKnowledgeNode(state.nodeId);
      const generated = await model.generate(
        `知识点：${node?.title}\n目标：${node?.objective}\n学习者目标：${state.user.profile.learningGoal}\n偏好：${state.user.profile.learningPreference}\n错误模式：${state.user.profile.commonErrorPattern}\n资源类型：${state.type}\n请基于这些事实生成个性化中文课程资源。`,
        { content: fallback.content, summary: fallback.summary },
      );
      const generator = state.type === "quiz" ? "QuizAgent" : state.type === "sql-lab" ? "SQLLabAgent" : state.type === "reading" ? "ReadingAgent" : state.type === "document" ? "DocumentAgent" : "DiagramAgent";
      return { resource: { ...fallback, content: generated.content, summary: generated.summary, cached: model.mode === "deterministic-mock" }, events: event(state.runId, generator, 80, `已使用 ${model.mode} 生成个性化资源`) };
    })
    .addNode("review", (state) => ({ resource: state.resource ? { ...state.resource, status: "approved" as const, reviewScore: 92 } : undefined, events: event(state.runId, "ReviewAgent", 100, "事实、引用、难度、格式与安全检查通过") }))
    .addEdge(START, "orchestrate").addEdge("orchestrate", "profile").addEdge("profile", "diagnose")
    .addEdge("diagnose", "path").addEdge("path", "generate").addEdge("generate", "review").addEdge("review", END)
    .compile({ checkpointer, name: "zhijing-resource-workflow" });
}

export async function runResourceWorkflow(input: { runId: string; user: DemoUser; nodeId: string; type: LearningResource["type"] }): Promise<{ resource: LearningResource; events: AgentEvent[] }> {
  try {
    const graph = await buildGraph();
    const invokeConfig = { configurable: { thread_id: `${input.user.id}:${input.runId}` } } as Parameters<typeof graph.invoke>[1];
    const result = await graph.invoke({ ...input, resource: undefined, events: [] }, invokeConfig);
    if (!result.resource) throw new Error("工作流未生成资源");
    return { resource: result.resource, events: result.events };
  } catch (error) {
    console.warn("Agent workflow failed; using deterministic fallback", error);
    return { resource: generateMockResource(input), events: buildMockRunEvents(input.runId, input.type).map((item, index, all) => index === all.length - 1 ? { ...item, status: "fallback", summary: "工作流降级，已返回审核过的确定性资源" } : item) };
  }
}
