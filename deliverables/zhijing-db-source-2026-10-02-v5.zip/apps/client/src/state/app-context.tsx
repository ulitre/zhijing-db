import { createContext, useContext, useState, type PropsWithChildren } from "react";
import { generateResource, getDashboard, isApiConfigured, submitDiagnostic } from "../lib/api";
type Persona = "foundation" | "exam" | "practice";
type UserSummary = { id: string; username: string; displayName: string; persona: Persona; goal: string };
type PathItem = { id: string; title: string; reason: string; mastery: number; status: string; resource: string };
type ResourceItem = { id: string; type: string; title: string; summary: string; status: string; score: number };
const users: UserSummary[] = [
  { id: "demo-foundation", username: "foundation", displayName: "基础薄弱型学生", persona: "foundation", goal: "补齐关系模型与 SQL 基础" },
  { id: "demo-exam", username: "exam", displayName: "应试巩固型学生", persona: "exam", goal: "巩固规范化与高频易错点" },
  { id: "demo-practice", username: "practice", displayName: "实践导向型学生", persona: "practice", goal: "掌握事务、索引和查询优化" },
];
const pathByPersona: Record<Persona, PathItem[]> = {
  foundation: [{ id: "relations", title: "关系、元组、属性与域", reason: "最优先的基础断点", mastery: 48, status: "active", resource: "图解" }, { id: "keys", title: "键与关系完整性", reason: "SQL 与设计的前置知识", mastery: 35, status: "recommended", resource: "分步讲解" }, { id: "sql", title: "SELECT 与联表查询", reason: "连接校园选课案例", mastery: 44, status: "recommended", resource: "SQL 实操" }],
  exam: [{ id: "closure", title: "属性闭包与候选键", reason: "规范化证明的知识断点", mastery: 52, status: "active", resource: "高频练习" }, { id: "nf", title: "第三范式与 BCNF", reason: "期末高频考点", mastery: 46, status: "recommended", resource: "错因卡片" }, { id: "tx", title: "隔离级别与并发异常", reason: "需要快速巩固", mastery: 58, status: "recommended", resource: "对比题" }],
  practice: [{ id: "isolation", title: "并发异常与隔离级别", reason: "从会写 SQL 进阶到工程实践", mastery: 52, status: "active", resource: "事务实验" }, { id: "index", title: "复合与覆盖索引", reason: "查询优化的关键基础", mastery: 48, status: "recommended", resource: "SQL 实操" }, { id: "plan", title: "执行计划与 EXPLAIN", reason: "验证索引是否生效", mastery: 42, status: "recommended", resource: "交互图解" }],
};
const initialResources: ResourceItem[] = [{ id: "r1", type: "知识图解", title: "候选键、主键与外键：一图辨析", summary: "以校园选课系统为例，逐步拆解键的职责。", status: "已审核", score: 94 }, { id: "r2", type: "SQL 实操", title: "三表联查：学生的课程清单", summary: "可执行、可验证的 JOIN 练习。", status: "已审核", score: 92 }, { id: "r3", type: "复习卡片", title: "关系模型 5 分钟回顾", summary: "面向当前知识断点的短时复习材料。", status: "缓存", score: 90 }];
const resourceTypeLabels: Record<string, string> = { document: "讲解文档", diagram: "知识图解", quiz: "分层练习", "sql-lab": "SQL 实操", visual: "交互图解", reading: "复习卡片" };
const resourceStatusLabels: Record<string, string> = { approved: "已审核", reviewing: "审核中", generating: "生成中", fallback: "已降级", rejected: "未通过" };
const mapRemoteResource = (item: { id: string; type: string; title: string; summary: string; status: string; reviewScore: number }): ResourceItem => ({ id: item.id, type: resourceTypeLabels[item.type] ?? item.type, title: item.title, summary: item.summary, status: resourceStatusLabels[item.status] ?? item.status, score: item.reviewScore });
type DiagnosticAnswer = { nodeId: string; correctness: number; usedHint: boolean; confidence: number };
type AppState = { demoUsers: UserSummary[]; currentUser: UserSummary; path: PathItem[]; resources: ResourceItem[]; loading: boolean; selectUser: (id: string) => Promise<void>; completeDiagnostic: (answers: DiagnosticAnswer[]) => Promise<void>; addGeneratedResource: (type: string) => Promise<void> };
const AppContext = createContext<AppState | null>(null);
export function AppProvider({ children }: PropsWithChildren) {
  const [currentUser, setCurrentUser] = useState(users[0]!); const [resources, setResources] = useState(initialResources); const [remotePath, setRemotePath] = useState<PathItem[] | null>(null); const [loading, setLoading] = useState(false);
  const selectUser = async (id: string) => {
    setLoading(true); const selected = users.find((user) => user.id === id) ?? users[0]!; setCurrentUser(selected);
    try {
      if (!isApiConfigured()) throw new Error("local demo");
      const dashboard = await getDashboard(selected.id);
      setRemotePath(dashboard.path.map((item) => ({ ...item, resource: item.recommendedResource })));
      if (dashboard.resources.length) setResources(dashboard.resources.map(mapRemoteResource));
    } catch { setRemotePath(null); await new Promise((resolve) => setTimeout(resolve, 180)); }
    finally { setLoading(false); }
  };
  const addGeneratedResource = async (type: string) => {
    const typeMap: Record<string, string> = { "讲解文档": "document", "知识图解": "diagram", "分层练习": "quiz", "SQL 实操": "sql-lab", "交互图解": "visual", "复习卡片": "reading" };
    const pendingId = `generating-${Date.now()}`;
    setResources((items) => [{ id: pendingId, type, title: `正在生成${type}…`, summary: "资源代理正在结合当前画像与知识断点生成内容。", status: "生成中", score: 0 }, ...items]);
    try {
      if (!isApiConfigured()) throw new Error("local demo");
      const nodeId = currentUser.persona === "foundation" ? "keys-integrity" : currentUser.persona === "exam" ? "nf-3bc" : "index-design";
      const { resource } = await generateResource({ userId: currentUser.id, nodeId, type: typeMap[type] ?? "document" });
      setResources((items) => [mapRemoteResource(resource), ...items.filter((item) => item.id !== pendingId && item.id !== resource.id)]);
    } catch { setResources((items) => [{ id: `generated-${Date.now()}`, type, title: type === "SQL 实操" ? "校园选课事务与索引实验" : `${currentUser.displayName}专属${type}`, summary: `依据${currentUser.goal}与当前掌握度动态生成。`, status: "已审核", score: 92 }, ...items.filter((item) => item.id !== pendingId)]); }
  };
  const completeDiagnostic = async (answers: DiagnosticAnswer[]) => {
    setLoading(true);
    try {
      if (!isApiConfigured()) throw new Error("local demo");
      const result = await submitDiagnostic({ userId: currentUser.id, answers });
      setRemotePath(result.path.map((item) => ({ ...item, resource: item.recommendedResource })));
    } catch { setRemotePath(pathByPersona[currentUser.persona]); }
    finally { setLoading(false); }
  };
  const value = { demoUsers: users, currentUser, path: remotePath ?? pathByPersona[currentUser.persona], resources, loading, selectUser, completeDiagnostic, addGeneratedResource };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useApp() { const context = useContext(AppContext); if (!context) throw new Error("useApp must be used inside AppProvider"); return context; }
