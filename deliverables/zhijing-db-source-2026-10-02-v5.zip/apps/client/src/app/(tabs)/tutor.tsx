import { useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { GlassCard, PageHeader, palette } from "../../components/design-system";
import { ScreenShell } from "../../components/screen-shell";
import { askTutor, type TutorResponse } from "../../lib/api";
import { useApp } from "../../state/app-context";

const localAnswer: TutorResponse = {
  answer: "候选键是能够唯一标识元组的最小属性集，可能有多个；主键是从候选键中选定的一个。以校园选课系统为例，学生表可以同时拥有学号和内部编号两个候选键，但系统会选择其中一个作为主键。",
  citations: [{ id: "local-database-design", title: "BCcampus Database Design · PostgreSQL Constraints" }],
  refused: false,
};

function localTutorFallback(question: string): TutorResponse {
  const normalized = question.replace(/事物(?=(?:的)?(?:四大|特性|性质|acid|原子性|一致性|隔离性|持久性))/gi, "事务");
  if (/(事务|acid|原子性|一致性|隔离性|持久性)/i.test(normalized)) return {
    answer: "事务的四大特性称为 ACID：原子性表示操作全部成功或全部回滚；一致性表示事务前后满足完整性约束；隔离性表示并发事务互不干扰；持久性表示提交结果不会因故障丢失。",
    citations: [{ id: "local-postgresql-transactions", title: "PostgreSQL Documentation · Transactions" }],
    refused: false,
  };
  const inScope = /(数据库|sql|候选键|主键|外键|关系|事务|索引|范式|查询|表|join)/i.test(normalized);
  return inScope
    ? localAnswer
    : { answer: "这个问题超出了《数据库原理》课程知识库范围。请围绕 SQL、数据库设计、事务、索引或安全继续提问。", citations: [], refused: true };
}

export default function TutorScreen() {
  const { currentUser } = useApp();
  const [question, setQuestion] = useState(""); const [lastQuestion, setLastQuestion] = useState(""); const [response, setResponse] = useState<TutorResponse | null>(null); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  const ask = async () => {
    const value = question.trim(); if (!value || loading) return;
    setLastQuestion(value); setQuestion(""); setLoading(true); setError(""); setResponse(null);
    try { setResponse(await askTutor({ userId: currentUser.id, question: value })); }
    catch (reason) { setResponse(localTutorFallback(value)); setError(reason instanceof Error ? "当前使用本地课程知识库回答" : "已切换到本地课程知识库"); }
    finally { setLoading(false); }
  };
  return <ScreenShell><PageHeader title="AI 辅导" subtitle="只回答《数据库原理》范围，并提供可追踪知识来源" />
    <GlassCard accent><Text style={styles.label}>当前学习节点</Text><Text style={styles.node}>键与关系完整性</Text><Text style={styles.hint}>试着问：“候选键和主键到底有什么区别？”</Text></GlassCard>
    {lastQuestion ? <View style={[styles.bubble, styles.userBubble]}><Text style={styles.userText}>{lastQuestion}</Text></View> : null}
    {response ? <View style={[styles.bubble, response.refused ? styles.refusedBubble : styles.aiBubble]}><Text style={styles.aiTitle}>{response.refused ? "范围审核" : "TutorAgent"}</Text><Text style={styles.aiText}>{response.answer}</Text>{response.citations.length ? <View style={styles.citationBox}><Text style={styles.citationTitle}>引用依据</Text>{response.citations.map((citation) => <Text key={citation.id} style={styles.citation}>{citation.title}</Text>)}</View> : null}</View> : loading ? <GlassCard><View style={styles.loadingRow}><ActivityIndicator color={palette.purple} /><Text style={styles.empty}>正在检索课程知识库…</Text></View></GlassCard> : !lastQuestion ? <GlassCard><Text style={styles.emptyTitle}>基于证据的即时辅导</Text><Text style={styles.empty}>系统会先检索课程知识卡，再生成解释；超出课程范围时明确拒答。</Text></GlassCard> : null}
    {error ? <Text style={styles.fallback}>{error}</Text> : null}
    <View style={styles.composer}><TextInput value={question} onChangeText={(text) => { setQuestion(text); setError(""); }} placeholder="输入数据库原理问题…" placeholderTextColor="#A397B2" style={styles.input} multiline /><Pressable disabled={loading || !question.trim()} onPress={() => void ask()} style={[styles.send, (loading || !question.trim()) && styles.sendDisabled]}>{loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.sendText}>发送</Text>}</Pressable></View>
    <Text style={styles.disclaimer}>AI 生成内容仅供学习参考 · 重要结论请核对引用来源</Text>
  </ScreenShell>;
}
const styles = StyleSheet.create({ label: { color: palette.purple, fontSize: 11, fontWeight: "900" }, node: { color: palette.ink, fontSize: 19, fontWeight: "900", marginTop: 6 }, hint: { color: palette.muted, fontSize: 12, marginTop: 7 }, bubble: { padding: 16, borderRadius: 20, maxWidth: "92%" }, userBubble: { alignSelf: "flex-end", backgroundColor: palette.purple }, aiBubble: { alignSelf: "flex-start", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: palette.line }, refusedBubble: { alignSelf: "flex-start", backgroundColor: "#FFF7ED", borderWidth: 1, borderColor: "#FDBA74" }, userText: { color: "#FFFFFF", fontWeight: "700" }, aiTitle: { color: palette.purple, fontWeight: "900", fontSize: 11 }, aiText: { color: palette.ink, lineHeight: 22, marginTop: 8 }, citationBox: { marginTop: 12, padding: 11, borderRadius: 13, backgroundColor: "#F4EEFA" }, citationTitle: { color: palette.muted, fontSize: 9, fontWeight: "900" }, citation: { color: "#523B70", fontSize: 10, marginTop: 4 }, fallback: { color: palette.muted, fontSize: 10, textAlign: "center" }, emptyTitle: { color: palette.ink, fontSize: 16, fontWeight: "900" }, empty: { color: palette.muted, lineHeight: 20, marginTop: 6 }, loadingRow: { flexDirection: "row", alignItems: "center", gap: 10 }, composer: { flexDirection: "row", alignItems: "flex-end", gap: 8, backgroundColor: "#FFFFFF", borderRadius: 20, borderWidth: 1, borderColor: palette.line, padding: 8 }, input: { flex: 1, minHeight: 44, maxHeight: 110, color: palette.ink, paddingHorizontal: 10, paddingVertical: 10 }, send: { backgroundColor: palette.purple, borderRadius: 14, minHeight: 44, paddingHorizontal: 16, alignItems: "center", justifyContent: "center" }, sendDisabled: { opacity: 0.55 }, sendText: { color: "#FFFFFF", fontWeight: "900" }, disclaimer: { color: palette.muted, fontSize: 10, textAlign: "center" } });
