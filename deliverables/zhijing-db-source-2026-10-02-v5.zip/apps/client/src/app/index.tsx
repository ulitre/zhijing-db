import { useState } from "react";
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { useApp } from "../state/app-context";
import { BrandHeader, GlassCard, PersonaBadge } from "../components/design-system";

export default function LoginScreen() {
  const { demoUsers, selectUser, loading } = useApp();
  const [selected, setSelected] = useState("demo-foundation");
  const enter = async () => { await selectUser(selected); router.replace("/diagnostic"); };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.page}>
    <BrandHeader eyebrow="MULTI-AGENT LEARNING" title="知径 DB" subtitle="每一次学习，都生成一条真正属于你的数据库知识路径。" />
    <View style={styles.heroStats}><Text style={styles.heroStat}>12 个智能体</Text><Text style={styles.dot}>•</Text><Text style={styles.heroStat}>45 个知识节点</Text><Text style={styles.dot}>•</Text><Text style={styles.heroStat}>6 类资源</Text></View>
    <GlassCard><Text style={styles.cardTitle}>选择演示学习者</Text><Text style={styles.cardSubtitle}>同一门课，不同画像会得到不同路径和资源。</Text>
      <View style={styles.personaList}>{demoUsers.map((user) => <Pressable key={user.id} onPress={() => setSelected(user.id)} style={[styles.persona, selected === user.id && styles.personaSelected]}>
        <PersonaBadge persona={user.persona} /><View style={styles.personaText}><Text style={styles.personaTitle}>{user.displayName}</Text><Text style={styles.personaSubtitle}>{user.goal}</Text></View><Text style={styles.chevron}>{selected === user.id ? "✓" : "›"}</Text>
      </Pressable>)}</View>
      <Pressable onPress={enter} style={styles.primaryButton} disabled={loading}>{loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>进入个性化学习空间</Text>}</Pressable>
      <Text style={styles.disclaimer}>演示账号使用虚构数据 · AI 生成内容仅供学习参考</Text>
    </GlassCard>
  </ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#17102F" }, page: { flexGrow: 1, padding: 24, paddingTop: 52, gap: 22, maxWidth: 760, width: "100%", alignSelf: "center" }, heroStats: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 8 }, heroStat: { color: "#DDD6FE", fontSize: 13, fontWeight: "700" }, dot: { color: "#8B5CF6" }, cardTitle: { color: "#1F163D", fontSize: 22, fontWeight: "800" }, cardSubtitle: { color: "#6F6685", marginTop: 6, marginBottom: 18, lineHeight: 21 }, personaList: { gap: 10 }, persona: { flexDirection: "row", alignItems: "center", padding: 14, borderWidth: 1, borderColor: "#E7E0F2", borderRadius: 18, backgroundColor: "#FFFFFF" }, personaSelected: { borderColor: "#7C3AED", backgroundColor: "#F7F2FF" }, personaText: { flex: 1, marginHorizontal: 12 }, personaTitle: { color: "#251846", fontSize: 15, fontWeight: "800" }, personaSubtitle: { color: "#746B84", fontSize: 12, marginTop: 3, lineHeight: 17 }, chevron: { color: "#7C3AED", fontSize: 22, fontWeight: "800" }, primaryButton: { marginTop: 18, minHeight: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#6D28D9" }, primaryButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 15 }, disclaimer: { color: "#9188A2", fontSize: 11, textAlign: "center", marginTop: 12 },
});
