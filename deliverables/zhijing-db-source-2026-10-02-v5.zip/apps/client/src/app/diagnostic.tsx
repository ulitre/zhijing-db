import { useState } from "react";
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { GlassCard, ProgressBar, palette } from "../components/design-system";
import { useApp } from "../state/app-context";

const questions = [
  { nodeId: "relations", text: "如果把学生表中的一行叫作什么，你最有把握？", choices: [{ label: "元组", score: 100 }, { label: "属性", score: 20 }, { label: "不确定，想先看提示", score: 45, hint: true }] },
  { nodeId: "keys-integrity", text: "候选键和主键的关系，你会怎样判断？", choices: [{ label: "主键是选定的一个候选键", score: 100 }, { label: "两者完全相同且都只能有一个", score: 25 }, { label: "我容易混淆", score: 50, hint: true }] },
  { nodeId: "sql-select", text: "查询成绩不低于 80 的学生，你能独立写出 WHERE 条件吗？", choices: [{ label: "能，并且会处理 NULL", score: 95 }, { label: "能写基础条件", score: 72 }, { label: "需要示例", score: 38, hint: true }] },
  { nodeId: "sql-joins", text: "学生、选课、课程三表联查时，你通常卡在哪里？", choices: [{ label: "可以独立确定连接条件", score: 92 }, { label: "会混淆连接键", score: 55 }, { label: "还不会 JOIN", score: 25, hint: true }] },
  { nodeId: "tx-acid", text: "最后一题：你能解释事务为什么需要原子性吗？", choices: [{ label: "能结合失败回滚解释", score: 96 }, { label: "记得定义但不会举例", score: 62 }, { label: "暂时不能", score: 28, hint: true }] },
] as const;

type Answer = { nodeId: string; correctness: number; usedHint: boolean; confidence: number };

export default function DiagnosticScreen() {
  const { currentUser, completeDiagnostic, loading } = useApp();
  const [step, setStep] = useState(0); const [answers, setAnswers] = useState<Answer[]>([]);
  const question = questions[step]!;
  const choose = async (choice: (typeof question.choices)[number]) => {
    const next = [...answers, { nodeId: question.nodeId, correctness: choice.score, usedHint: "hint" in choice && Boolean(choice.hint), confidence: choice.score >= 90 ? 90 : choice.score >= 60 ? 70 : 45 }];
    setAnswers(next);
    if (step < questions.length - 1) setStep((value) => value + 1);
    else { await completeDiagnostic(next); router.replace("/(tabs)"); }
  };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.page}>
    <Text style={styles.eyebrow}>DIAGNOSIS AGENT · {step + 1}/{questions.length}</Text>
    <Text style={styles.title}>先聊几句，再为你规划</Text>
    <Text style={styles.subtitle}>你好，{currentUser.displayName}。这不是考试，我会根据回答动态调整后续问题和学习路径。</Text>
    <ProgressBar value={((step + 1) / questions.length) * 100} />
    <View style={styles.chatRow}><View style={styles.avatar}><Text style={styles.avatarText}>D</Text></View><GlassCard accent><Text style={styles.agent}>DiagnosisAgent</Text><Text style={styles.question}>{question.text}</Text></GlassCard></View>
    <View style={styles.choices}>{question.choices.map((choice) => <Pressable disabled={loading} key={choice.label} onPress={() => void choose(choice)} style={styles.choice}><Text style={styles.choiceText}>{choice.label}</Text><Text style={styles.arrow}>›</Text></Pressable>)}</View>
    {loading ? <View style={styles.loading}><ActivityIndicator color={palette.purple} /><Text style={styles.loadingText}>正在更新八维画像和动态路径…</Text></View> : null}
    <Text style={styles.note}>回答仅用于本次演示画像 · 可在“我的”页面查看变化</Text>
  </ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: "#F7F4FC" }, page: { flexGrow: 1, width: "100%", maxWidth: 720, alignSelf: "center", padding: 24, paddingTop: 52, gap: 18 }, eyebrow: { color: palette.purple, fontWeight: "900", fontSize: 11, letterSpacing: 1.2 }, title: { color: palette.ink, fontWeight: "900", fontSize: 28 }, subtitle: { color: palette.muted, lineHeight: 22 }, chatRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginTop: 18 }, avatar: { width: 38, height: 38, borderRadius: 14, backgroundColor: palette.purple, alignItems: "center", justifyContent: "center" }, avatarText: { color: "white", fontWeight: "900" }, agent: { color: palette.purple, fontWeight: "900", fontSize: 11 }, question: { color: palette.ink, fontSize: 19, lineHeight: 28, fontWeight: "800", marginTop: 8 }, choices: { gap: 10 }, choice: { flexDirection: "row", alignItems: "center", minHeight: 58, backgroundColor: "white", borderWidth: 1, borderColor: "#E5DDF2", borderRadius: 17, paddingHorizontal: 17 }, choiceText: { color: palette.ink, fontWeight: "700", flex: 1 }, arrow: { color: palette.purple, fontSize: 24 }, loading: { flexDirection: "row", gap: 10, alignItems: "center", justifyContent: "center" }, loadingText: { color: palette.muted, fontSize: 12 }, note: { color: palette.muted, fontSize: 11, textAlign: "center", marginTop: "auto" } });
