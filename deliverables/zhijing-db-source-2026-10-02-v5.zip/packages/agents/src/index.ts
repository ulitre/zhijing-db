import { getKnowledgeNode, knowledgeNodes } from "@zhijing/course-data";
import type {
  AgentEvent,
  AgentName,
  DemoUser,
  LearnerProfile,
  LearningResource,
  MasteryEvidence,
  PathStep,
} from "@zhijing/shared";

export const AGENTS: ReadonlyArray<{ name: AgentName; responsibility: string }> = [
  { name: "Orchestrator", responsibility: "固定图编排、检查点和失败降级" },
  { name: "ProfileAgent", responsibility: "从对话、诊断和行为更新八维画像" },
  { name: "DiagnosisAgent", responsibility: "定位知识断点、前置缺失和错误模式" },
  { name: "PathAgent", responsibility: "按知识依赖与掌握度规划动态学习路径" },
  { name: "DocumentAgent", responsibility: "生成个性化知识讲解文档" },
  { name: "DiagramAgent", responsibility: "生成知识导图与结构图" },
  { name: "QuizAgent", responsibility: "生成分层练习、答案和解析" },
  { name: "SQLLabAgent", responsibility: "生成可验证的 SQL 实操任务" },
  { name: "ReadingAgent", responsibility: "生成拓展阅读与复习卡片" },
  { name: "ReviewAgent", responsibility: "审核事实、引用、难度、安全与格式" },
  { name: "TutorAgent", responsibility: "基于课程证据提供即时辅导" },
  { name: "EvaluationAgent", responsibility: "评估学习效果并触发路径重规划" },
] as const;

export const demoUsers: DemoUser[] = [
  {
    id: "demo-foundation",
    username: "foundation",
    displayName: "基础薄弱型学生",
    persona: "foundation",
    profile: {
      prerequisiteFoundation: 42,
      knowledgeMastery: { relations: 48, "keys-integrity": 35, "sql-select": 44 },
      learningGoal: "补齐关系模型基础，并能独立完成校园选课系统的基础查询",
      learningPreference: "visual",
      weeklyMinutes: 240,
      commonErrorPattern: "容易混淆主键、候选键与外键",
      resourcePreference: ["diagram", "document"],
      progressTrend: "stable",
    },
  },
  {
    id: "demo-exam",
    username: "exam",
    displayName: "应试巩固型学生",
    persona: "exam",
    profile: {
      prerequisiteFoundation: 72,
      knowledgeMastery: { relations: 82, "keys-integrity": 76, "fd-anomalies": 58, "nf-3bc": 46 },
      learningGoal: "在短时间内巩固规范化、事务与高频易错题",
      learningPreference: "concise",
      weeklyMinutes: 180,
      commonErrorPattern: "会套范式结论，但不会用闭包证明",
      resourcePreference: ["quiz", "reading"],
      progressTrend: "rising",
    },
  },
  {
    id: "demo-practice",
    username: "practice",
    displayName: "实践导向型学生",
    persona: "practice",
    profile: {
      prerequisiteFoundation: 78,
      knowledgeMastery: { "sql-select": 88, "sql-joins": 84, "nf-3bc": 55, isolation: 52, "index-design": 48 },
      learningGoal: "通过可执行案例掌握事务、索引和查询优化",
      learningPreference: "practice",
      weeklyMinutes: 360,
      commonErrorPattern: "能写出查询，但缺少执行计划和并发意识",
      resourcePreference: ["sql-lab", "visual"],
      progressTrend: "rising",
    },
  },
];

export function calculateEvidenceScore(evidence: MasteryEvidence): number {
  return Math.round(
    evidence.correctness * 0.6 +
      evidence.hintIndependence * 0.15 +
      evidence.responseQuality * 0.15 +
      evidence.confidenceCalibration * 0.1,
  );
}

export function updateMastery(oldMastery: number, evidence: MasteryEvidence): number {
  const score = calculateEvidenceScore(evidence);
  return Math.max(0, Math.min(100, Math.round(oldMastery * 0.7 + score * 0.3)));
}

function preferredResource(profile: LearnerProfile): PathStep["recommendedResource"] {
  if (profile.learningPreference === "visual") return "diagram";
  if (profile.learningPreference === "practice") return "sql-lab";
  if (profile.learningPreference === "concise") return "quiz";
  return "document";
}

export function planLearningPath(profile: LearnerProfile, limit = 8): PathStep[] {
  const mastery = profile.knowledgeMastery;
  const weakNodes = knowledgeNodes
    .map((node) => ({ node, mastery: mastery[node.id] ?? profile.prerequisiteFoundation }))
    .filter(({ mastery: value }) => value < 80)
    .sort((a, b) => a.mastery - b.mastery || a.node.difficulty - b.node.difficulty);

  const selected = new Map<string, (typeof weakNodes)[number]>();
  const addWithPrerequisites = (nodeId: string) => {
    const node = getKnowledgeNode(nodeId);
    if (!node || selected.has(nodeId)) return;
    for (const prerequisite of node.prerequisites) {
      if ((mastery[prerequisite] ?? profile.prerequisiteFoundation) < 80) addWithPrerequisites(prerequisite);
    }
    selected.set(nodeId, { node, mastery: mastery[nodeId] ?? profile.prerequisiteFoundation });
  };

  for (const candidate of weakNodes) {
    addWithPrerequisites(candidate.node.id);
    if (selected.size >= limit) break;
  }

  return [...selected.values()].slice(0, limit).map(({ node, mastery: value }, index) => ({
    id: `step-${index + 1}-${node.id}`,
    nodeId: node.id,
    title: node.title,
    reason:
      index === 0
        ? `当前掌握度 ${value}，是最优先的知识断点`
        : `它是后续知识的前置基础，当前掌握度 ${value}`,
    mastery: value,
    status: index === 0 ? "active" : "recommended",
    recommendedResource: preferredResource(profile),
  }));
}

function resourceBody(type: LearningResource["type"], nodeTitle: string, profile: LearnerProfile): string {
  const intro = `本资源围绕“${nodeTitle}”，根据你的目标“${profile.learningGoal}”生成。`;
  const bodies: Record<LearningResource["type"], string> = {
    document: `${intro}\n\n先用校园选课系统解释核心概念，再给出定义、反例和自检问题。`,
    diagram: `${intro}\n\nflowchart LR\n  业务规则 --> 实体与联系\n  实体与联系 --> 关系模式\n  关系模式 --> 约束与查询`,
    quiz: `${intro}\n\n1. 判断当前设计中的主键与外键。\n2. 解释错误选项对应的概念混淆。`,
    "sql-lab": `${intro}\n\nSELECT s.name, c.title\nFROM enrollment e\nJOIN student s ON s.id = e.student_id\nJOIN course c ON c.id = e.course_id;`,
    visual: `${intro}\n\n交互步骤：观察关系结构 → 修改约束 → 比较异常 → 查看修复后的模式。`,
    reading: `${intro}\n\n复习卡：概念、触发条件、常见错误、校园选课案例、下一步学习建议。`,
  };
  return bodies[type];
}

export function generateMockResource(input: {
  user: DemoUser;
  nodeId: string;
  type: LearningResource["type"];
}): LearningResource {
  const node = getKnowledgeNode(input.nodeId) ?? knowledgeNodes[0]!;
  const reasons = [
    `匹配学习偏好：${input.user.profile.learningPreference}`,
    `针对错误模式：${input.user.profile.commonErrorPattern}`,
    `当前掌握度：${input.user.profile.knowledgeMastery[node.id] ?? input.user.profile.prerequisiteFoundation}`,
  ];
  return {
    id: `resource-${input.user.id}-${node.id}-${input.type}`,
    userId: input.user.id,
    nodeId: node.id,
    type: input.type,
    title: `${node.title} · ${input.user.displayName}专属资源`,
    summary: node.objective,
    content: resourceBody(input.type, node.title, input.user.profile),
    difficulty: Math.max(1, Math.min(5, node.difficulty)),
    status: "approved",
    reviewScore: 92,
    sourceIds: node.sourceIds,
    personalizationReasons: reasons,
    cached: true,
    createdAt: new Date().toISOString(),
  };
}

export function buildMockRunEvents(runId: string, type: LearningResource["type"]): AgentEvent[] {
  const generator: AgentName =
    type === "document"
      ? "DocumentAgent"
      : type === "diagram" || type === "visual"
        ? "DiagramAgent"
        : type === "quiz"
          ? "QuizAgent"
          : type === "sql-lab"
            ? "SQLLabAgent"
            : "ReadingAgent";
  const steps: Array<[AgentName, string]> = [
    ["Orchestrator", "已创建确定性工作流并载入检查点"],
    ["ProfileAgent", "已读取八维画像与最近学习证据"],
    ["DiagnosisAgent", "已定位知识断点和前置依赖"],
    ["PathAgent", "已确认当前路径节点和资源策略"],
    [generator, "已生成匹配难度、形式和案例的资源"],
    ["ReviewAgent", "引用、个性化、格式和安全检查已通过"],
  ];
  return steps.map(([agent, summary], index) => ({
    runId,
    agent,
    status: "completed",
    progress: Math.round(((index + 1) / steps.length) * 100),
    summary,
    elapsedMs: 180 + index * 240,
    timestamp: new Date(Date.now() + index * 250).toISOString(),
  }));
}
