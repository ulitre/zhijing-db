import { useState } from "react";
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { GlassCard, palette } from "../components/design-system";
import { executeSql } from "../lib/api";
import { useApp } from "../state/app-context";

const starterSql = `SELECT s.name AS student_name, c.title AS course_title, e.score
FROM enrollment e
JOIN student s ON s.id = e.student_id
JOIN course c ON c.id = e.course_id
WHERE e.score >= 85
ORDER BY e.score DESC`;

type Result = { columns: string[]; rows: unknown[][]; rowCount: number; elapsedMs: number; sandbox: string };

export default function SqlLabScreen() {
  const { currentUser } = useApp(); const [sql, setSql] = useState(starterSql); const [result, setResult] = useState<Result | null>(null); const [error, setError] = useState(""); const [running, setRunning] = useState(false); if (!currentUser) return null;
  const run = async () => { setRunning(true); setError(""); try { setResult(await executeSql({ userId: currentUser.id, mode: "query", sql })); } catch (reason) { setResult(null); setError(reason instanceof Error ? reason.message : "执行失败"); } finally { setRunning(false); } };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.page}>
    <Pressable onPress={() => router.back()}><Text style={styles.back}>‹ 返回资源库</Text></Pressable>
    <Text style={styles.eyebrow}>SQLLAB AGENT · ISOLATED WORKER</Text><Text style={styles.title}>校园选课 SQL 实验室</Text><Text style={styles.subtitle}>每次执行都会创建全新的内存数据库；结果最多 200 行，超过 2 秒自动终止。</Text>
    <GlassCard><Text style={styles.label}>练习：查询 85 分及以上的学生、课程与成绩</Text><TextInput value={sql} onChangeText={setSql} multiline autoCapitalize="none" spellCheck={false} style={styles.editor} /><Pressable disabled={running} onPress={() => void run()} style={styles.run}>{running ? <ActivityIndicator color="white" /> : <Text style={styles.runText}>▶ 在安全沙箱中执行</Text>}</Pressable></GlassCard>
    {error ? <GlassCard><Text style={styles.error}>安全提示：{error}</Text></GlassCard> : null}
    {result ? <GlassCard><View style={styles.resultHead}><Text style={styles.resultTitle}>查询结果 · {result.rowCount} 行</Text><Text style={styles.meta}>{result.sandbox} · {result.elapsedMs} ms</Text></View><ScrollView horizontal><View><View style={styles.row}>{result.columns.map((column) => <Text key={column} style={[styles.cell, styles.headerCell]}>{column}</Text>)}</View>{result.rows.map((row, index) => <View key={index} style={styles.row}>{row.map((cell, cellIndex) => <Text key={cellIndex} style={styles.cell}>{String(cell)}</Text>)}</View>)}</View></ScrollView></GlassCard> : null}
    <Text style={styles.note}>禁止 ATTACH、PRAGMA、扩展加载与多语句执行；实验库与业务数据库完全隔离。</Text>
  </ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: "#F7F4FC" }, page: { width: "100%", maxWidth: 800, alignSelf: "center", padding: 22, paddingTop: 42, gap: 15 }, back: { color: palette.purple, fontWeight: "800" }, eyebrow: { color: palette.purple, fontWeight: "900", fontSize: 11, letterSpacing: 1 }, title: { color: palette.ink, fontWeight: "900", fontSize: 27 }, subtitle: { color: palette.muted, lineHeight: 21 }, label: { color: palette.ink, fontWeight: "800", marginBottom: 10 }, editor: { minHeight: 180, borderRadius: 14, padding: 14, backgroundColor: "#17102F", color: "#EDE9FE", fontFamily: "monospace", fontSize: 13, lineHeight: 21, textAlignVertical: "top" }, run: { marginTop: 12, minHeight: 48, borderRadius: 13, backgroundColor: palette.purple, alignItems: "center", justifyContent: "center" }, runText: { color: "white", fontWeight: "900" }, error: { color: "#B42318", fontWeight: "700", lineHeight: 20 }, resultHead: { flexDirection: "row", justifyContent: "space-between", marginBottom: 12, gap: 12 }, resultTitle: { color: palette.ink, fontWeight: "900" }, meta: { color: palette.success, fontSize: 11, fontWeight: "800" }, row: { flexDirection: "row" }, cell: { width: 150, padding: 10, borderWidth: 0.5, borderColor: "#E4DCF0", color: palette.ink, fontSize: 12 }, headerCell: { backgroundColor: "#EEE7FA", color: palette.purple, fontWeight: "900" }, note: { color: palette.muted, textAlign: "center", fontSize: 11, lineHeight: 18 } });
