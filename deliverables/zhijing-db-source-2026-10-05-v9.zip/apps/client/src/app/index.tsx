import { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { BrandHeader, GlassCard } from "../components/design-system";
import { useApp } from "../state/app-context";

export default function LoginScreen() {
  const { currentUser, login, loading, ready } = useApp(); const [username, setUsername] = useState(""); const [password, setPassword] = useState(""); const [error, setError] = useState("");
  useEffect(() => { if (!ready || currentUser) return; void AsyncStorage.getItem("zhijing.onboarding.v1").then((seen) => { if (!seen) router.replace("/onboarding" as never); }); }, [ready, currentUser]);
  useEffect(() => { if (ready && currentUser) router.replace("/(tabs)"); }, [ready, currentUser]);
  const submit = async () => { setError(""); try { await login(username.trim(), password); router.replace("/diagnostic"); } catch (reason) { setError(reason instanceof Error ? reason.message : "登录失败，请检查账号密码"); } };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.page}>
    <BrandHeader eyebrow="MULTI-AGENT LEARNING" title="知径 DB" subtitle="登录后获得基于诊断证据的数据库学习路径。" />
    <View style={styles.heroStats}><Text style={styles.heroStat}>12 个智能体</Text><Text style={styles.dot}>•</Text><Text style={styles.heroStat}>45 个知识节点</Text><Text style={styles.dot}>•</Text><Text style={styles.heroStat}>6 类资源</Text></View>
    <GlassCard><Text style={styles.cardTitle}>账号登录</Text><Text style={styles.cardSubtitle}>使用演示账号体验个性化学习空间</Text>
      <Text style={styles.label}>用户名</Text><TextInput accessibilityLabel="用户名" autoCapitalize="none" value={username} onChangeText={setUsername} placeholder="foundation / exam / practice" style={styles.input} />
      <Text style={styles.label}>密码</Text><TextInput accessibilityLabel="密码" secureTextEntry value={password} onChangeText={setPassword} placeholder="请输入密码" style={styles.input} onSubmitEditing={() => void submit()} />
      {error ? <Text accessibilityRole="alert" style={styles.error}>{error}</Text> : null}
      <Pressable onPress={() => void submit()} style={styles.primaryButton} disabled={loading || !ready}>{loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>登录并进入学习空间</Text>}</Pressable>
      <Text style={styles.disclaimer}>演示密码：demo1234 · 首次登录后可在“我的”中退出</Text>
    </GlassCard>
    <Pressable onPress={() => router.push("/help" as never)} style={styles.help}><Text style={styles.helpText}>使用帮助</Text></Pressable>
  </ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: "#17102F" }, page: { flexGrow: 1, padding: 24, paddingTop: 52, gap: 22, maxWidth: 760, width: "100%", alignSelf: "center" }, heroStats: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 8 }, heroStat: { color: "#DDD6FE", fontSize: 13, fontWeight: "700" }, dot: { color: "#8B5CF6" }, cardTitle: { color: "#1F163D", fontSize: 22, fontWeight: "800" }, cardSubtitle: { color: "#6F6685", marginTop: 6, marginBottom: 18, lineHeight: 21 }, label: { color: "#493C63", fontWeight: "800", fontSize: 12, marginTop: 10, marginBottom: 6 }, input: { minHeight: 48, borderWidth: 1, borderColor: "#E7E0F2", borderRadius: 13, paddingHorizontal: 13, color: "#251846", backgroundColor: "#FFFFFF" }, primaryButton: { marginTop: 18, minHeight: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#6D28D9" }, primaryButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 15 }, disclaimer: { color: "#9188A2", fontSize: 11, textAlign: "center", marginTop: 12 }, error: { color: "#B42318", marginTop: 9, fontWeight: "700" }, help: { padding: 12, alignItems: "center" }, helpText: { color: "#DDD6FE", fontWeight: "800" } });
